sample_data was generated using the given model and the command

simulate(po,nsim=1,params=c(beta_sd= 0.1, beta1 = 1.5, mu=0.1, gamma=0.6, rho= 0.8, N=N, S.0= S.0, I.0 = I.0, RealCases.0 = 1),as.data.frame=T)
